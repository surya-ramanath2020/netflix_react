import React from 'react'
import './Footer.css'

function Footer() {



  return (
    
        <footer className="footer py-5 text-center">
   Copy right &copy; 2022 Movie Zone - Developed by Jasir
  </footer>
  
    
  )
}

export default Footer